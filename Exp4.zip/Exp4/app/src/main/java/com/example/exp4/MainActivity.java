package com.example.exp4;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editTextUserName, editTextPassword, editTextAddress, editTextAge;
    RadioGroup radioGroupGender;
    RadioButton radioButtonMale, radioButtonFemale;
    DatePicker datePickerDOB;
    Spinner spinnerState;
    Button buttonSubmit;
    TextView textViewUserData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        editTextUserName = findViewById(R.id.editTextUserName);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextAge = findViewById(R.id.editTextAge);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        radioButtonMale = findViewById(R.id.radioButtonMale);
        radioButtonFemale = findViewById(R.id.radioButtonFemale);
        datePickerDOB = findViewById(R.id.datePickerDOB);
        spinnerState = findViewById(R.id.spinnerState);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        textViewUserData = findViewById(R.id.textViewUserData);
    }

    public void onSubmitButtonClick(View view) {
        // Get user inputs
        String userName = editTextUserName.getText().toString();
        String password = editTextPassword.getText().toString();
        String address = editTextAddress.getText().toString();
        String gender = radioButtonMale.isChecked() ? "Male" : "Female";
        int age = Integer.parseInt(editTextAge.getText().toString());
        int day = datePickerDOB.getDayOfMonth();
        int month = datePickerDOB.getMonth() + 1; // Month starts from 0
        int year = datePickerDOB.getYear();
        String dob = day + "/" + month + "/" + year;
        String state = spinnerState.getSelectedItem().toString();

        // Display user data
        String userData = "User Name: " + userName + "\n" +
                "Password: " + password + "\n" +
                "Address: " + address + "\n" +
                "Gender: " + gender + "\n" +
                "Age: " + age + "\n" +
                "Date of Birth: " + dob + "\n" +
                "State: " + state;

        textViewUserData.setText(userData);
    }
}